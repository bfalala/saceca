package fr.n7.saceca.u3du.model.ai.agent.module.planning.initialization;

import java.util.ArrayList;

import fr.n7.saceca.u3du.model.ai.service.PropertyLink;
import fr.n7.saceca.u3du.model.ai.service.Service;
import fr.n7.saceca.u3du.model.ai.service.ServiceProperty;

public class GenerateProperties {
	private ArrayList<Service> serviceList;
	
	private ArrayList<ServiceProperty> propertyList;
	
	private ArrayList<PropertyLink> linkList;
	
	public GenerateProperties(ArrayList<Service> serviceList, ArrayList<PropertyLink> linkList) {
		this.serviceList = new ArrayList<Service>();
		for (Service service : serviceList) {
			this.serviceList.add(service.deepDataClone());
		}
		
		this.getPropertiesFromServiceList();
		
		this.linkList = new ArrayList<PropertyLink>();
		for (PropertyLink link : linkList) {
			this.linkList.add(link.deepDataClone());
		}
	}
	
	public GenerateProperties(String actionFile, String linkFile) {
		// this.serviceList = new ArrayList<Service>();
		// this.propertyList = new ArrayList<ServiceProperty>();
		
		// XStream xstr = new XStream();
		
		// try {
		// FileInputStream fileStr = new FileInputStream(actionFile);
		// xstr.alias("actions", ArrayList.class);
		// xstr.alias("action", Service.class);
		// xstr.alias("property", ServiceProperty.class);
		// xstr.alias("param", Param.class);
		
		// this.serviceList = (ArrayList<Service>) xstr.fromXML(fileStr);
		
		// this.propertyList = this.getPropertiesFromActionsTab(this.serviceList);
		
		// System.out.print("num actions: " + actionsTab.size() + " num properties: " +
		// propertiesTab.size());
		// } catch (Exception e) {
		// }
		
		// this.linkList = new ArrayList<PropertyLink>();
		
		// xstr = new XStream();
		
		// try {
		// FileInputStream fileStr = new FileInputStream(linkFile);
		// xstr.alias("links", ArrayList.class);
		// xstr.alias("link", PropertyLink.class);
		// xstr.alias("premise", ServiceProperty.class);
		// xstr.alias("conclusion", ServiceProperty.class);
		
		// this.linkList = (ArrayList<PropertyLink>) xstr.fromXML(fileStr);
		// } catch (Exception e) {
		// }
		
	}
	
	public ArrayList<ServiceProperty> getPropertiesFromServiceList() {
		this.propertyList = new ArrayList<ServiceProperty>();
		
		for (Service service : this.serviceList) {
			for (ServiceProperty property : service.getServicePreconditions()) {
				if (!this.existProperty(property, this.propertyList)) {
					this.propertyList.add(property.deepDataClone());
				}
			}
			
			for (ServiceProperty property : service.getServiceEffectsPlus()) {
				if (!this.existProperty(property, this.propertyList)) {
					this.propertyList.add(property.deepDataClone());
				}
			}
			
			for (ServiceProperty property : service.getServiceEffectsMinus()) {
				if (!this.existProperty(property, this.propertyList)) {
					this.propertyList.add(property);
				}
			}
		}
		return this.propertyList;
	}
	
	private boolean existProperty(ServiceProperty property, ArrayList<ServiceProperty> propertyList) {
		for (ServiceProperty existing_property : propertyList) {
			if (property.egal(existing_property)) {
				if (existing_property.getTreatment_precond().equals("")) {
					existing_property.setTreatment_precond(property.getTreatment_precond());
				}
				if (existing_property.getTreatment_effect().equals("")) {
					existing_property.setTreatment_effect(property.getTreatment_effect());
				}
				return true;
			}
		}
		return false;
	}
	
	public ArrayList<Service> getServiceList() {
		return this.serviceList;
	}
	
	public void setServiceList(ArrayList<Service> serviceList) {
		this.serviceList = serviceList;
	}
	
	public ArrayList<ServiceProperty> getPropertyList() {
		return this.propertyList;
	}
	
	public void setPropertyList(ArrayList<ServiceProperty> propertyList) {
		this.propertyList = propertyList;
	}
	
	public ArrayList<PropertyLink> getLinkList() {
		return this.linkList;
	}
	
	public void setLinkList(ArrayList<PropertyLink> linkList) {
		this.linkList = linkList;
	}
	
}
