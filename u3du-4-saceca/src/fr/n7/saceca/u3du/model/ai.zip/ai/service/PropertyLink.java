package fr.n7.saceca.u3du.model.ai.service;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("link")
public class PropertyLink {
	@XStreamAlias("premise")
	private ServiceProperty premise;
	
	@XStreamAlias("conclusion")
	private ServiceProperty conclusion;
	
	public PropertyLink() {
		this.premise = new ServiceProperty();
		this.conclusion = new ServiceProperty();
	}
	
	public PropertyLink(ServiceProperty premise, ServiceProperty conclussion) {
		this.premise = premise.deepDataClone();
		this.conclusion = conclussion.deepDataClone();
	}
	
	public ServiceProperty getPremise() {
		return this.premise;
	}
	
	public void setPremise(ServiceProperty premise) {
		this.premise = premise;
	}
	
	public ServiceProperty getConclusion() {
		return this.conclusion;
	}
	
	public void setConclusion(ServiceProperty conclusion) {
		this.conclusion = conclusion;
	}
	
	public PropertyLink deepDataClone() {
		return new PropertyLink(this.premise.deepDataClone(), this.conclusion.deepDataClone());
	}
}
