package fr.n7.saceca.u3du.model.ai.service;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("param")
public class Param {
	@XStreamAlias("paramName")
	private String paramName;
	
	@XStreamAlias("paramValue")
	private String paramValue;
	
	@XStreamAlias("paramType")
	private String paramType;
	
	@XStreamAlias("fixed")
	private String fixed;
	
	@XStreamAlias("findValue")
	private String findValue;
	
	public Param(String name, String value, String type, String findValue, String fixed) {
		this.paramName = name;
		this.paramValue = value;
		this.paramType = type;
		this.fixed = fixed;
		this.findValue = findValue;
	}
	
	public Param() {
		this.paramName = "";
		this.paramType = "string";
		this.paramValue = "";
		this.fixed = "false";
		this.findValue = "";
	}
	
	public boolean egal(Param param) {
		if (!this.paramName.equals(param.paramName)) {
			return false;
		}
		if (!this.paramType.equals(param.paramType)) {
			return false;
		}
		return true;
	}
	
	public String getParamName() {
		return this.paramName;
	}
	
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	
	public String getParamValue() {
		return this.paramValue;
	}
	
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	
	public String getParamType() {
		return this.paramType;
	}
	
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	
	public void setFindValue(String findValue) {
		this.findValue = findValue;
	}
	
	public String getFindValue() {
		return this.findValue;
	}
	
	public void setFixed(String fixed) {
		this.fixed = fixed;
	}
	
	public String getFixed() {
		return this.fixed;
	}
	
	public Param deepDataClone() {
		return new Param(this.paramName, this.paramValue, this.paramType, this.findValue, this.fixed);
	}
}
