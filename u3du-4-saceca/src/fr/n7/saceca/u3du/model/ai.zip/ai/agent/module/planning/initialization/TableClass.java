package fr.n7.saceca.u3du.model.ai.agent.module.planning.initialization;

public class TableClass {
	private String name;
	
	private String value;
	
	public TableClass() {
		
	}
	
	public TableClass(String name, String value) {
		this.name = name;
		this.value = value;
	}
	
	public String getname() {
		return this.name;
	}
	
	public void setname(String name) {
		this.name = name;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
}