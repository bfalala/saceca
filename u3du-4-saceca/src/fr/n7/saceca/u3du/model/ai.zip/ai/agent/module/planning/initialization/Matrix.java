package fr.n7.saceca.u3du.model.ai.agent.module.planning.initialization;

import java.util.ArrayList;

import fr.n7.saceca.u3du.model.ai.service.PropertyLink;
import fr.n7.saceca.u3du.model.ai.service.Service;
import fr.n7.saceca.u3du.model.ai.service.ServiceProperty;

public class Matrix {
	
	private int[][] values;
	
	private char[][] p_order;
	
	public void createMatrixA(ArrayList<Service> serviceList, ArrayList<ServiceProperty> effectList) {
		int numRows = serviceList.size();
		int numColumns = effectList.size();
		
		this.values = new int[numRows][numColumns];
		
		int i = 0, j = 0;
		
		for (ServiceProperty effect : effectList) {
			j = 0;
			
			for (Service service : serviceList) {
				this.values[j][i] = 0;
				
				for (ServiceProperty effect_plus : service.getServiceEffectsPlus()) {
					if (effect.egal(effect_plus)) {
						this.values[j][i] = 1;
					}
				}
				
				for (ServiceProperty effect_minus : service.getServiceEffectsMinus()) {
					if (effect.egal(effect_minus)) {
						this.values[j][i] = -1;
					}
				}
				j++;
			}
			i++;
		}
		
	}
	
	public void createMatrixP(ArrayList<ServiceProperty> effectList, ArrayList<Service> serviceList) {
		int numRows = effectList.size();
		int numColumns = serviceList.size();
		
		this.values = new int[numRows][numColumns];
		this.p_order = new char[numRows][numColumns];
		
		int i = 0, j = 0;
		
		for (ServiceProperty effect : effectList) {
			j = 0;
			for (Service service : serviceList) {
				this.values[i][j] = 0;
				this.p_order[i][j] = '0';
				
				for (ServiceProperty precondition : service.getServicePreconditions()) {
					if (effect.egal(precondition)) {
						this.values[i][j] = 1;
						this.p_order[i][j] = precondition.getOrder();
					}
				}
				j++;
			}
			i++;
		}
	}
	
	public void createMatrixLink(ArrayList<PropertyLink> linkList) {
		this.values = new int[linkList.size()][linkList.size()];
	}
	
	public int[][] transposeMatrix() {
		int rows = this.values.length;
		int cols = this.values[0].length;
		
		int[][] result = new int[cols][rows];
		
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				result[j][i] = this.values[i][j];
			}
		}
		return result;
	}
	
	public char[][] cloneOrders() {
		char[][] orders = new char[this.p_order.length][this.p_order[0].length];
		for (int i = 0; i < this.p_order.length; i++) {
			for (int j = 0; j < this.p_order[0].length; j++) {
				orders[i][j] = this.p_order[i][j];
			}
		}
		return orders;
	}
	
	public int[][] getValues() {
		return this.values;
	}
	
	public void setValues(int[][] values) {
		this.values = values;
	}
	
	public char[][] getP_order() {
		return this.p_order;
	}
	
	public void setP_order(char[][] p_order) {
		this.p_order = p_order;
	}
	
	public void setP_orderElement(int i, int j, char value) {
		this.p_order[i][j] = value;
	}
	
	public char getP_orderElement(int i, int j) {
		return this.p_order[i][j];
	}
	
	public int getValuesRows() {
		return this.values.length;
	}
	
	public int getValuesColumns() {
		return this.values[0].length;
	}
	
	public int getP_orderRows() {
		return this.p_order.length;
	}
	
	public int getP_orderColumns() {
		return this.p_order[0].length;
	}
}
