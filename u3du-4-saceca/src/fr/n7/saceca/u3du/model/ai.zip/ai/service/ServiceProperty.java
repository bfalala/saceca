package fr.n7.saceca.u3du.model.ai.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("property")
public class ServiceProperty {
	@XStreamAlias("propertyName")
	private String propertyName;
	
	@XStreamAlias("propertyParameters")
	private ArrayList<Param> propertyParameters;
	
	@XStreamAlias("order")
	private char order;
	
	@XStreamAlias("treatment_precond")
	private String treatment_precond;
	
	@XStreamAlias("treatment_effect")
	private String treatment_effect;
	
	public ServiceProperty(String name, ArrayList<Param> param, char order, String treatment_precond,
			String treatment_effect) {
		this.propertyName = name;
		this.propertyParameters = param;
		this.order = order;
		this.treatment_effect = treatment_effect;
		this.treatment_precond = treatment_precond;
	}
	
	public ServiceProperty(String name, ArrayList<Param> param) {
		this.propertyName = name;
		this.propertyParameters = param;
		this.order = 0;
		this.treatment_effect = "";
		this.treatment_precond = "";
	}
	
	public ServiceProperty() {
		this.propertyName = "";
		this.propertyParameters = new ArrayList<Param>();
		this.order = 0;
		this.treatment_effect = "";
		this.treatment_precond = "";
	}
	
	public boolean egal(ServiceProperty propr) {
		if (!this.propertyName.equals(propr.getPropertyName())) {
			return false;
		}
		if (this.propertyParameters.size() != propr.getPropertyParameters().size()) {
			return false;
		}
		Iterator<Param> it_j = propr.getPropertyParameters().iterator();
		for (Param param : this.propertyParameters) {
			if (!param.egal(it_j.next())) {
				return false;
			}
		}
		return true;
	}
	
	public ServiceProperty deepDataClone() {
		ServiceProperty clone = new ServiceProperty(this.propertyName, null, this.order, this.treatment_precond,
				this.treatment_effect);
		
		ArrayList<Param> paramList = new ArrayList<Param>();
		for (Param parameter : this.propertyParameters) {
			paramList.add(parameter.deepDataClone());
		}
		
		clone.setPropertyParameters(paramList);
		
		return clone;
	}
	
	public ServiceProperty getConclussion(ArrayList<PropertyLink> linksTab) {
		ServiceProperty conclusion = new ServiceProperty();
		boolean found = false;
		for (int i = 0; i < linksTab.size(); i++) {
			if (linksTab.get(i).getPremise().egal(this)) {
				found = true;
				conclusion = linksTab.get(i).getConclusion().deepDataClone();
				break;
			}
		}
		if (found) {
			for (int i = 0; i < conclusion.getPropertyParameters().size(); i++) {
				Param param = conclusion.getPropertyParameters().get(i);
				
				if (param.getFixed().equals("false")) {
					for (int j = 0; j < this.getPropertyParameters().size(); j++) {
						if (param.getParamName().equals(this.getPropertyParameters().get(j).getParamName())) {
							if (param.getFindValue().equals("")) {
								param.setParamValue(this.getPropertyParameters().get(j).getParamValue());
							} else {
								param.setParamValue(this.findTheValue(this.getPropertyParameters(),
										param.getFindValue()));
							}
						}
					}
				}
			}
			return conclusion;
		}
		
		return null;
	}
	
	private String findTheValue(ArrayList<Param> paramList, String findValue) {
		String[] args = findValue.split("__");
		String var1 = args[0], type = "";
		String operator = args[1];
		String var2 = args[2];
		String val1 = "", val2 = "";
		
		for (int i = 0; i < paramList.size(); i++) {
			if (paramList.get(i).getParamName().equals(var1)) {
				val1 = paramList.get(i).getParamValue();
				type = paramList.get(i).getParamType();
			}
			if (paramList.get(i).getParamName().equals(var2)) {
				val2 = paramList.get(i).getParamValue();
				type = paramList.get(i).getParamType();
			}
		}
		
		if (!(var1.equals("") || var2.equals("") || operator.equals(""))) {
			if (operator.equals("+")) {
				if (type.equals("double")) {
					return String.valueOf(Double.parseDouble(val1) + Double.parseDouble(val2));
				} else if (type.equals("int")) {
					return String.valueOf(Integer.parseInt(val1) + Integer.parseInt(val2));
				}
				
			} else if (operator.equals("-")) {
				if (type.equals("double")) {
					return String.valueOf(Double.parseDouble(val1) - Double.parseDouble(val2));
				} else if (type.equals("int")) {
					return String.valueOf(Integer.parseInt(val1) - Integer.parseInt(val2));
				}
			}
		}
		
		return "";
	}
	
	public String getPropertyName() {
		return this.propertyName;
	}
	
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	public ArrayList<Param> getPropertyParameters() {
		return this.propertyParameters;
	}
	
	public void setPropertyParameters(ArrayList<Param> propertyParameters) {
		this.propertyParameters = propertyParameters;
	}
	
	public char getOrder() {
		return this.order;
	}
	
	public void setOrder(char order) {
		this.order = order;
	}
	
	public String getTreatment_precond() {
		return this.treatment_precond;
	}
	
	public void setTreatment_precond(String treatment_precond) {
		this.treatment_precond = treatment_precond;
	}
	
	public String getTreatment_effect() {
		return this.treatment_effect;
	}
	
	public void setTreatment_effect(String treatment_effect) {
		this.treatment_effect = treatment_effect;
	}
	
	public Param getParameter(int index) {
		return this.propertyParameters.get(index);
	}
	
	public void setParameter(int index, Param parameter) {
		this.propertyParameters.set(index, parameter);
	}
	
	public void setLastParameter(Param parameter) {
		this.setParameter(this.propertyParameters.size() - 1, parameter);
	}
	
	public Param getLastParameter() {
		return this.getParameter(this.propertyParameters.size() - 1);
	}
	
	public Param getParameter(String name) {
		for (Param parameter : this.propertyParameters) {
			if (parameter.getParamName().equals(name)) {
				return parameter;
			}
		}
		return null;
	}
}
