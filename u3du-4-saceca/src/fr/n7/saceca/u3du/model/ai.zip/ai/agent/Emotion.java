package fr.n7.saceca.u3du.model.ai.agent;

import fr.n7.saceca.u3du.model.ai.object.properties.DoublePropertyModel;
import fr.n7.saceca.u3du.model.ai.object.properties.Property;
import fr.n7.saceca.u3du.model.ai.object.properties.UnknownPropertyException;
import fr.n7.saceca.u3du.model.util.Periodic;

public class Emotion extends Property<Double> {
	
	/** The Constant PREFIX. */
	public static final String PREFIX = "i_emotion_";
	
	/** The Constant DECREMENT_PERIOD_PREFIX. */
	public static final String DECREMENT_PERIOD_PREFIX = "i_decrement_period_";
	
	/** The Constant SURVIVAL_SUFFIXES. */
	// public static final String[] SURVIVAL_SUFFIXES = { "hunger", "tiredness", "thirst" };
	
	/** The gauge decrement time. */
	private int emotionDecrementTime;
	
	/**
	 * Instantiates a new gauge.
	 * 
	 * @param prop
	 *            the prop
	 */
	public Emotion(Property<Double> prop) {
		super(prop.getModel());
		this.setValue(prop.getValue());
		this.emotionDecrementTime = 0;
	}
	
	/**
	 * Gets the min value.
	 * 
	 * @return the min value
	 */
	public double getMinValue() {
		DoublePropertyModel model = (DoublePropertyModel) this.getModel();
		return model.getMinValue();
	}
	
	/**
	 * Gets the max value.
	 * 
	 * @return the max value
	 */
	public double getMaxValue() {
		DoublePropertyModel model = (DoublePropertyModel) this.getModel();
		return model.getMaxValue();
	}
	
	/**
	 * Decrement.
	 * 
	 * @param decrementValue
	 *            the decrement value
	 */
	public void decrement(double decrementValue) {
		this.setValue(this.getValue() - decrementValue);
		if (this.getValue() < this.getMinValue()) {
			this.setValue(this.getMinValue());
		}
	}
	
	/**
	 * Decrement.
	 */
	public void decrement() {
		this.decrement(1);
	}
	
	/**
	 * Increment.
	 * 
	 * @param incrementValue
	 *            the increment value
	 */
	public void increment(double incrementValue) {
		this.setValue(this.getValue() + incrementValue);
		if (this.getValue() > this.getMaxValue()) {
			this.setValue(this.getMaxValue());
		}
	}
	
	/**
	 * Increment.
	 */
	public void increment() {
		this.increment(1);
	}
	
	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return this.getModel().getName();
	}
	
	@Override
	public String toString() {
		return super.toString() + " (Emotion)";
	}
	
	/**
	 * Gets the gauge name suffix.
	 * 
	 * @return the name suffix
	 */
	public String getNameSuffix() {
		return this.getModel().getName().replace(PREFIX, "");
	}
	
	/**
	 * Gets the gauge decrement period.
	 * 
	 * @param agent
	 *            the agent who owns this gauge
	 * @return the decrement period
	 */
	private Integer getDecrementPeriod(Agent agent) {
		Integer emotionDecrementPeriod = null;
		
		// Case when there is a decrement period for the current gauge
		try {
			emotionDecrementPeriod = agent.getPropertiesContainer().getInt(
					DECREMENT_PERIOD_PREFIX + this.getNameSuffix());
		}
		// Case when there the decrement period is not found. We use the default decrement period.
		catch (UnknownPropertyException e) {
			try {
				emotionDecrementPeriod = agent.getPropertiesContainer().getInt(DECREMENT_PERIOD_PREFIX + "default");
			} catch (UnknownPropertyException e1) {
				e.printStackTrace();
			}
		}
		
		return emotionDecrementPeriod;
	}
	
	/**
	 * Decrements the gauge periodically.
	 * 
	 * @param agent
	 *            the agent
	 */
	public void periodicDecrement(Agent agent) {
		int decrementPeriod = this.getDecrementPeriod(agent);
		
		if (this.emotionDecrementTime == decrementPeriod - 1) {
			this.decrement();
		}
		
		this.emotionDecrementTime = Periodic.incrementPeriodTime(this.emotionDecrementTime, decrementPeriod);
	}
}